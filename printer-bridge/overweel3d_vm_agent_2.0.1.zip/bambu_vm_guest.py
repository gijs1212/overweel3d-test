"""Runs inside the Windows VM and talks directly to the Home Assistant add-on."""
from __future__ import annotations

import argparse
import ftplib
import json
import logging
import os
import socket
import ssl
import tempfile
import time
import urllib.parse
import urllib.request
from pathlib import Path

from pywinauto import Desktop

ROOT = Path(__file__).resolve().parent
LOG = logging.getLogger("overweel3d-vm-guest")


class ImplicitFTP_TLS(ftplib.FTP_TLS):
    def connect(self, host="", port=0, timeout=-999, source_address=None):
        if host:
            self.host = host
        if port:
            self.port = port
        if timeout != -999:
            self.timeout = timeout
        self.sock = socket.create_connection((self.host, self.port), self.timeout, source_address=source_address)
        self.af = self.sock.family
        self.sock = self.context.wrap_socket(self.sock, server_hostname=self.host)
        self.file = self.sock.makefile("r", encoding=self.encoding)
        self.welcome = self.getresp()
        return self.welcome


def addon_request(url: str, token: str, path: str, payload: dict | None = None) -> dict:
    data = json.dumps(payload).encode() if payload is not None else None
    request = urllib.request.Request(
        url.rstrip("/") + path,
        data=data,
        method="POST" if data is not None else "GET",
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
    )
    with urllib.request.urlopen(request, timeout=30) as response:
        return json.loads(response.read().decode() or "{}")


def temporary_sd_download(printer: dict, remote_path: str, destination: Path) -> None:
    context = ssl._create_unverified_context()
    ftp = ImplicitFTP_TLS(timeout=45, context=context)
    try:
        ftp.connect(str(printer["host"]), int(printer.get("ftps_port") or 990))
        ftp.login(str(printer.get("ftps_username") or "bblp"), str(printer["access_code"]))
        ftp.prot_p()
        with destination.open("wb") as output:
            ftp.retrbinary("RETR /" + remote_path.lstrip("/"), output.write, blocksize=256 * 1024)
    finally:
        try:
            ftp.quit()
        except ftplib.all_errors:
            ftp.close()


def click_configured(window, config: dict, name: str) -> None:
    selector = config.get(name) or {}
    auto_id = str(selector.get("auto_id") or "")
    title_re = str(selector.get("title_re") or "")
    coordinates = selector.get("coordinates")
    if auto_id:
        control = window.child_window(auto_id=auto_id)
        control.wait("enabled", timeout=20)
        control.click_input()
        return
    if title_re:
        control = window.child_window(title_re=title_re)
        control.wait("enabled", timeout=20)
        control.click_input()
        return
    if isinstance(coordinates, list) and len(coordinates) == 2:
        window.click_input(coords=(int(coordinates[0]), int(coordinates[1])))
        return
    raise RuntimeError(f"Geen veilige UI-selector ingesteld voor {name}")


def select_combo(window, selector: dict, value: str) -> None:
    auto_id = str(selector.get("auto_id") or "")
    title_re = str(selector.get("title_re") or "")
    if not auto_id and not title_re:
        raise RuntimeError("AMS/printer-combobox mist auto_id of title_re")
    control = window.child_window(auto_id=auto_id) if auto_id else window.child_window(title_re=title_re)
    control.wait("enabled", timeout=20)
    try:
        control.select(value)
    except Exception:
        control.click_input()
        control.type_keys("^a" + value + "{ENTER}", with_spaces=True)


def automate_bambu_connect(file_path: Path, job: dict, config: dict) -> None:
    query = urllib.parse.urlencode(
        {"path": str(file_path), "name": file_path.name, "version": "1.0.0"},
        quote_via=urllib.parse.quote,
    )
    os.startfile("bambu-connect://import-file?" + query)
    title_re = str(config.get("window_title_regex") or ".*Bambu Connect.*")
    window = Desktop(backend="uia").window(title_re=title_re)
    window.wait("visible", timeout=int(config.get("ui_timeout_seconds") or 120))
    window.set_focus()

    printer_name = str(config.get("printer_name") or "").strip()
    if printer_name:
        select_combo(window, config.get("printer_combobox") or {}, printer_name)

    mapping = [int(slot) for slot in (job.get("ams_mapping") or [])]
    selectors = config.get("ams_comboboxes") or []
    if mapping:
        if len(selectors) < len(mapping):
            raise RuntimeError(f"Voor {len(mapping)} kleuren zijn slechts {len(selectors)} AMS-selectors ingesteld")
        for index, slot in enumerate(mapping):
            # Website-AMS-slots zijn nulgebaseerd; de UI toont doorgaans 1..16.
            select_combo(window, selectors[index], str(slot + 1))

    if bool(config.get("disable_calibration", True)):
        for selector in config.get("calibration_checkboxes") or []:
            auto_id = str(selector.get("auto_id") or "")
            title_re = str(selector.get("title_re") or "")
            control = window.child_window(auto_id=auto_id) if auto_id else window.child_window(title_re=title_re)
            if control.exists(timeout=2) and control.get_toggle_state():
                control.click_input()

    click_configured(window, config, "send_button")
    confirm = config.get("confirm_button") or {}
    if confirm:
        time.sleep(1)
        click_configured(window, config, "confirm_button")
    LOG.info("Officiële Bambu Connect-UI heeft de printopdracht ontvangen")


def process_job(addon_url: str, addon_token: str, job_id: str, config: dict) -> bool:
    try:
        payload = addon_request(
            addon_url,
            addon_token,
            "/guest/job?" + urllib.parse.urlencode({"job_id": job_id}),
        )
        job = payload["job"]
        printer = payload["printer"]
        remote_path = str(job.get("sd_file_path") or "").strip()
        if not remote_path:
            raise RuntimeError("Wachtrij-item bevat geen SD-kaartpad")
        addon_request(addon_url, addon_token, "/guest/event", {"event": "downloading", "job_id": job_id})
        with tempfile.TemporaryDirectory(prefix="overweel3d-vm-print-") as temporary:
            local_file = Path(temporary) / Path(remote_path.replace("\\", "/")).name
            temporary_sd_download(printer, remote_path, local_file)
            LOG.info("FTPS-bestand gedownload: %s (%s bytes)", local_file.name, local_file.stat().st_size)
            addon_request(addon_url, addon_token, "/guest/event", {"event": "automating_bambu_connect", "job_id": job_id})
            automate_bambu_connect(local_file, job, config)
            addon_request(addon_url, addon_token, "/guest/event", {"event": "waiting_for_printer_confirmation", "job_id": job_id})
            # Houd de tijdelijke 3MF beschikbaar terwijl Bambu Connect hem verwerkt.
            time.sleep(int(config.get("keep_download_seconds") or 120))
        return True
    except Exception as exc:
        LOG.exception("VM-gasttaak mislukt")
        try:
            addon_request(addon_url, addon_token, "/guest/event", {"event": "guest_failed", "job_id": job_id, "error": str(exc)})
        except Exception:
            pass
        return False


def run_startup_agent(config: dict) -> int:
    addon_url = str(config.get("addon_url") or "").strip()
    addon_token = str(config.get("addon_token") or "").strip()
    if not addon_url or not addon_token:
        raise RuntimeError("vm-guest.json mist addon_url of addon_token")
    poll_seconds = max(2, int(config.get("poll_seconds") or 3))
    handled_jobs: set[str] = set()
    LOG.info("VM-agent 2.0.1 actief; meldt zich rechtstreeks bij de Home Assistant-add-on")
    while True:
        try:
            response = addon_request(
                addon_url,
                addon_token,
                "/guest/ready",
                {"version": "2.0.1", "state": "ready"},
            )
            job_id = str(response.get("runner_job_id") or "")
            if job_id and job_id not in handled_jobs:
                handled_jobs.add(job_id)
                LOG.info("Wachtrijtaak %s ontvangen; Bambu Connect-verwerking begint", job_id)
                process_job(addon_url, addon_token, job_id, config)
        except Exception as exc:
            LOG.warning("VM-agent kan de Home Assistant-add-on tijdelijk niet bereiken: %s", exc)
        time.sleep(poll_seconds)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--addon-url")
    parser.add_argument("--addon-token")
    parser.add_argument("--job-id")
    parser.add_argument("--agent", action="store_true")
    parser.add_argument("--config", default=str(ROOT / "vm-guest.json"))
    args = parser.parse_args()
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        handlers=[logging.FileHandler(ROOT / "vm-guest.log", encoding="utf-8"), logging.StreamHandler()],
    )
    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    if args.addon_url:
        config["addon_url"] = args.addon_url
    if args.addon_token:
        config["addon_token"] = args.addon_token
    if args.agent:
        return run_startup_agent(config)
    if not args.addon_url or not args.addon_token or not args.job_id:
        parser.error("Gebruik --agent of geef --addon-url, --addon-token en --job-id op")
    return 0 if process_job(args.addon_url, args.addon_token, args.job_id, config) else 1


if __name__ == "__main__":
    raise SystemExit(main())
