# PocketBase voor Overweel3D

Deze app gebruikt blijvende PocketBase-data uit `/data` en laadt JavaScript-hooks uit:

```text
/share/pocketbase/pb_hooks
```

De routefile en bijbehorende kernmodule zitten in het apppakket en worden bij
het starten automatisch in deze map geplaatst of bijgewerkt. Bij het bijwerken
bewaart de app de vorige versies met de extensie `.backup`.

Controle na de start:

```text
https://api.gijsoverweel.nl/api/overweel3d/health
```

Bij upgrades zoekt de app naar bestaande `data.db`-bestanden in `/data` en
`/share/pocketbase`. De grootste bestaande database wordt gekozen en de keuze
wordt blijvend vastgelegd. Dit voorkomt dat een lege database na een wijziging
van het opslagpad wordt geopend.

Het antwoord hoort `"ok": true` en hookversie `1.3.19` te bevatten. Bambu-kleurcatalogussynchronisatie vergelijkt ieder officieel voorstel op materiaal en naam/hexcode en bewaart uitsluitend onbekende kleuren als niet-openbaar voorstel. De aparte **Refresh AMS**-actie gebruikt blijvende verzoek- en bevestigingsnummers in de bestaande printerstatus en wijzigt geen printer-, pc-, VM-, mappen- of bestandsstatus. Printerkoppelinstellingen en wachtrij-items worden zonder optionele `created`- of `updated`-sorteervelden gelezen.

De RPC `request_printer_full_refresh` zet het map- en bestandsverzoek atomair
klaar. De bridge verwerkt deze altijd in de volgorde status/AMS, mappen en
bestanden.
